import { create, decryptMedia } from '@open-wa/wa-automate';

import memeGenerator from '../../utils/memeGenerator';
import audioProcessing from '../../utils/audioProcessing';
import moment, { tz, locale } from 'moment-timezone';

import color from '../../lib/color';
import privateMessages from '../../utils/privateMessages';

tz.setDefault('America/Sao_Paulo');
locale('id');

const uaOverride = process.env.UA;
module.exports = async (client, message) => {
  const botNumber = await client.getHostNumber();
  if (message.type === 'audio' && message.isGroupMsg != true) {
    await client.sendText(message.from, privateMessages.processing);

    const mediaData = await decryptMedia(message, uaOverride);
    const transformedAudio = await audioProcessing.speedAudio(
      mediaData.toString('base64')
    );
    const base64Audio = `data:${message.mimetype};base64,${transformedAudio}`;
    await client.sendAudio(message.from, base64Audio);
    await client.sendText(message.from, privateMessages.finishMessage);
  }

  try {
    if (message.body === `@${botNumber}`) {
      if (message.quotedMsg.type === 'image') {
        co;

        const mediaData = await decryptMedia(message.quotedMsg, uaOverride);
        const imageBase64 = `data:${message.quotedMsg.mimetype
          };base64,${mediaData.toString('base64')}`;
        return await client.sendImageAsSticker(message.from, imageBase64);
      }
    }
  } catch (err) {
    console.log(color('[ERRO]', 'red'), err);
  }

  try {
    if (message.body === `@${botNumber}`) {
      if (message.quotedMsg.type === 'audio') {
        await client.sendText(message.from, privateMessages.processing);
        co;
        const mediaData = await decryptMedia(message.quotedMsg, uaOverride);
        const transformedAudio = await audioProcessing.speedAudio(
          mediaData.toString('base64')
        );
        const base64Audio = `data:${message.quotedMsg.mimetype};base64,${transformedAudio}`;
        await client.sendAudio(message.from, base64Audio);
      }
    }
  } catch (err) {
    console.log(color('[ERRO]', 'red'), err);
  }

  try {
    const {
      type,
      id,
      from,
      t,
      sender,
      isGroupMsg,
      chat,
      caption,
      isMedia,
      mimetype,
      quotedMsg,
      mentionedJidList,
    } = message;
    let { body } = message;

    const { name } = chat;
    let { pushname, verifiedName } = sender;
    pushname = pushname || verifiedName;
    // if (pushname === undefined) console.log(sender + '\n\n' + chat);
    const prefix = '#';
    body =
      type === 'chat' && body.startsWith(prefix)
        ? body
        : (type === 'image' || type === 'video') &&
          caption &&
          caption.startsWith(prefix)
          ? caption
          : '';
    const command = body
      .slice(prefix.length)
      .trim()
      .split(/ +/)
      .shift()
      .toLowerCase();
    const args = body.slice(prefix.length).trim().split(/ +/).slice(1);
    const isCmd = body.startsWith(prefix);
    const time = moment(t * 1000).format('DD/MM HH:mm:ss');
    if (!isCmd && !isGroupMsg)
      return console.log(
        '[MENSAGEM]',
        color(time, 'yellow'),
        'Mensagem de',
        color(pushname)
      );
    if (!isCmd && isGroupMsg)
      return console.log(
        '[MENSAGEM]',
        color(time, 'yellow'),
        'Mensagem de',
        color(pushname),
        'em',
        color(name)
      );
    if (isCmd && !isGroupMsg)
      console.log(
        color('[COMANDO]'),
        color(time, 'yellow'),
        color(`${command} [${args.length}]`),
        'de',
        color(pushname)
      );
    if (isCmd && isGroupMsg)
      console.log(
        color('[COMANDO]'),
        color(time, 'yellow'),
        color(`${command} [${args.length}]`),
        'de',
        color(pushname),
        'em',
        color(name)
      );
    const groupId = isGroupMsg ? chat.groupMetadata.id : '';
    const groupAdmins = isGroupMsg ? await client.getGroupAdmins(groupId) : '';
    const groupMembers = isGroupMsg
      ? await client.getGroupMembersId(groupId)
      : '';
    const isGroupAdmins = isGroupMsg ? groupAdmins.includes(sender.id) : false;
    const isBotGroupAdmins = isGroupMsg
      ? groupAdmins.includes(botNumber + '@c.us')
      : false;

    switch (command) {
      default:
        await client.sendText(from, privateMessages.default);
        break;
      case 'status':
        const totalChats = async () => {
          const contacts = await client.getAllChats();
          const groups = await client.getAllGroups();

          var contactsArray = [];
          let groupsArray = [];

          contacts.forEach((value) => {
            contactsArray.push(value.id);
          });

          groups.forEach((value) => {
            groupsArray.push(value.id);
          });

          return [contactsArray.length, groupsArray.length];
        };
        const finalTotal = await totalChats();
        await client.sendText(
          from,
          ` 😻 _estou presente em_ ${finalTotal[1]} _grupos e tenho_ ${finalTotal[0]} _usuários privados_`
        );
        break;
      case '':
        await client.sendContact(from, '554891051634@c.us');
        break;
      case '':
        function sleep(ms) {
          return new Promise((resolve) => setTimeout(resolve, ms));
        }

        const spamMessage = args.join(','.replace(',', ' '));

        const contacts = await client.getAllChats();
        const groups = await client.getAllGroups();

        let contactsArray = [];
        let groupsArray = [];

        // groups.forEach((value) => {
        //   groupsArray.push(value.id)
        // })

        contacts.forEach((value) => {
          contactsArray.push(value.id);
        });

        // await client.sendText(from, contactsArray)

        contactsArray.forEach(async (value) => {
          await client.sendText(value, spamMessage);
          sleep(1000);
        });

        // groupsArray.forEach(async (value) => {
        //   await client.sendText(value, spamMessage)
        // })

        break;
      case 'catsticker':
        await client.sendText(from, privateMessages.catsticker);
        break;
      case 'donate':
        await client.sendText(from, privateMessages.donate);
        break;
      case '':
        await client.sendText(from, privateMessages.icon);
        break;
      case '':
        await client.sendText(from, privateMessages.csg);
        break;
      case 'ajuda':
        await client.sendText(from, privateMessages.help);
        break;

      case '':
        await client.sendText(from, privateMessages.grupo);
        break;

      case '':
        if (isMedia) {
          await client.sendText(from, privateMessages.processing);
          const mediaData = await decryptMedia(message, uaOverride);
          const base64 = `${mediaData.toString('base64')}`;

          // console.log(mimetype);
          const dataURI = `data:${mimetype};base64,${base64}`;

          const stickerName = await gifSticker.upload(dataURI);
          const base64WEBP = await gifSticker.grabWebp(stickerName);
          // console.log("")
          try {
            await client.sendRawWebpAsSticker(from, base64WEBP, true);
            return client.sendText(from, privateMessages.finishMessage);
          } catch (error) {
            return client.sendText(from, privateMessages.gifError);
          }
        }
        break;

      case 'meme':
        if (isMedia) {
          await client.sendText(from, privateMessages.processing);
          let caption = body.replace('#meme', '').split('|');

          const mediaData = await decryptMedia(message, uaOverride);
          const imageBase64 = `${mediaData.toString('base64')}`;

          const image_url = await memeGenerator.upload(imageBase64);

          const createdMeme = await memeGenerator.createMeme(
            image_url,
            caption[0],
            caption[1]
          );

          const base64Meme = `data:${mimetype};base64,${createdMeme}`;

          await client.sendImageAsSticker(from, base64Meme);
          return client.sendText(from, privateMessages.finishMessage);
        }
        break;
      case 'sticker':
        if (isMedia) {
          if (args && args[0] === '') {
            await client.sendText(from, privateMessages.processing);
            const mediaData = await decryptMedia(message, uaOverride);
            const sticker = await removeBG.remove(mediaData.toString('base64'));

            const imageBase64 = `data:${mimetype};base64,${sticker}`;
            try {
              return await client.sendImageAsSticker(from, imageBase64);
            } catch {
              return await client.sendText(
                from,
                privateMessages.backgroundError
              );
            }
          }

          await client.sendText(from, privateMessages.processing);
          const mediaData = await decryptMedia(message, uaOverride);
          const imageBase64 = `data:${mimetype};base64,${mediaData.toString(
            'base64'
          )}`;
          await client.sendImageAsSticker(from, imageBase64);
          return client.sendText(from, privateMessages.finishMessage);
        }
        if (!isMedia) {
          return await client.sendText(from, privateMessages.invalidMedia);
        }

        break;
      case '':
        const joinLink = args[0]
        const joinStatus = await client.joinGroupViaLink(joinLink)
        if (joinStatus != 401) {
          await client.sendText(from, "entrou")
        }
        else {
          await client.sendText(from, "Erro ao entrar")

        }
        break;
    }
  } catch (err) {
    console.log(color('[ERRO]', 'red'), err);
  }
};
