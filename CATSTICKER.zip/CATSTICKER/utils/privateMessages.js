module.exports = {
  default: `🐱 digite: *#ajuda* para ver a lista de comandos`,
  onJoinedGroup: `/ᐠ . ̫ .ᐟ\\ᵐᵉᵒʷˎ digite *#ajuda* para saber mais!`,
  invalidMedia: `😿 Você precisa enviar uma imagem, digite *#ajuda*`,
  processing: `​🧶 processando...🐈`,
  finishMessage: `/ᐠ . ̫ .ᐟ\\ᵐᵉᵒʷˎˊ Pronto!!
digite *#ajuda* Para ver a lista de comandos
by: *@lulcasmelo* & *@1baianito*`,
  help: `*=^._.^= ∫ PARA CRIAR SUA FIGURINHA VOCÊ PRECISA ENVIAR UMA OU MAIS IMAGENS,*

  *tutorial* _em vídeo twitter:_
  *https://twitter.com/lulcasmelo/status/1321924174076588033*
  
  *tutorial* _em vídeo instagram:_
  *https://www.instagram.com/s/aGlnaGxpZ2h0OjE3ODg1MjM3Nzc2ODU2Nzcw?igshid=1rxp6fukbzxmb*
  
  *NA DESCRIÇÃO DE CADA IMAGEM _DIGITE_ UM DOS SEGUINTES*
  *_COMANDOS_ PARA EXECUTAR A FUNÇÃO STICKER DESEJADA:*
  
    *#sticker* _para criar uma figurinha._ 
        
    *#meme* _cria a figurinha e adiciona texto._
    ex: #meme _para texto centralizado_
    ex: #meme _Texto de cima | Texto de baixo_
    
     *🐱 OUTROS COMANDOS*
        
    *#catsticker* _informações gerais sobre o bot_
  
    *#donate* _apoie o projeto_
  
    *#status* _estatística de usuários_    
  
  *Acelere áudios longos de seus colegas, basta encaminhar um ou mais áudios para o privado do bot.*

  😺*https://lulcasmelo.com/catsticker* _Tutorial de como criar seu catsticker_
  
  by: *@lulcasmelo* & *@1baianito*`,
  donate: `ฅ/ᐠ. ̫ .ᐟ\\ฅ *Apoie nosso projeto.

*PicPay:* @catsticker
*https://apoia.se/catsticker*
*https://www.vakinha.com.br/vaquinha/catsticker*

by: *@lulcasmelo* & *@1baianito*`,
  catsticker:  `🐈 *Catsticker é um bot livre*.
quer  ter uma versão do bot e rodar o catsticker para seus amigos?.

😺*https://lulcasmelo.com/catsticker* _Tutorial de como criar seu catsticker_

by: *@lulcasmelo* & *@1baianito*.
  ` ,
};

//"vai la amigo, deleta as mensagens do gatinho, parabéns :)"