const axios = require('axios');
const fs = require('fs').promises;
const exec = require('child_process').exec;
var crypto = require('crypto');

const UPLOAD_API = '752bbfd38f161baee9fd72f31c0b282b';
const EXPIRE_TIME = '600';

function execPromise(command) {
  return new Promise(function (resolve, reject) {
    exec(command, (error, stdout, stderr) => {
      if (error) {
        reject(error);
        return;
      }

      resolve();
    });
  });
}

class memeGenerator {
  async upload(base64) {
    const params = new URLSearchParams();
    params.append('image', base64);

    const display_url = await axios
      .post(
        `https://api.imgbb.com/1/upload?expire=${EXPIRE_TIME}&key=${UPLOAD_API}`,
        params
      )
      .then((response) => {
        if (response.data && response.data.data.display_url) {
          return response.data.data.display_url;
        }
      });

    return display_url;
  }

  async createMeme(image_url, topText, bottomText) {
    const entry = crypto.randomBytes(5).toString('hex');
    // const exit = crypto.randomBytes(5).toString('hex');

    const data = {
      image_url,
      text_lines: [topText, bottomText],
      extension: 'string',
      redirect: true,
    };

    const result = await axios
      .post(`https://api.memegen.link/templates/custom`, data, {
        responseType: 'arraybuffer',
        headers: {
          'Content-Type': 'application/json'
        }
      })
      .then(async (response) => {
        await fs.writeFile(`${entry}.png`, response.data, 'binary', () => { });

        await execPromise(
          `convert ${entry}.png -resize 512x512\! ${entry}.png`
        );

        const base64 = await fs.readFile(
          `${entry}.png`,
          { encoding: 'base64' },
          () => { }
        );

        await fs.unlink(`./${entry}.png`, () => { });

        return base64;
        // return Buffer.from(`${entry}.png`, 'binary').toString('base64');
      });

    return result;
  }
}

export default new memeGenerator();
