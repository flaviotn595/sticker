const fs = require('fs').promises;
var crypto = require('crypto');
const exec = require('child_process').exec;
function execPromise(command) {
  return new Promise(function (resolve, reject) {
    exec(command, (error, stdout, stderr) => {
      if (error) {
        reject(error);
        return;
      }

      resolve();
    });
  });
}

class audioProcessing {

  async speedAudio(base64Audio) {
    const entry = crypto.randomBytes(5).toString('hex');
    const exit = crypto.randomBytes(5).toString('hex');

    await fs.writeFile(entry + '.mp3', base64Audio, 'base64', () => { });

    await execPromise(`ffmpeg -i ${entry}.mp3 -filter:a "atempo=1.5" -q:a 100 ${exit}.mp3`);

    const returnData = await fs.readFile(
      `${exit}.mp3`,
      { encoding: 'base64' },
      () => { }
    );

    await fs.unlink(`./${entry}.mp3`, () => { });
    await fs.unlink(`./${exit}.mp3`, () => { });

    return returnData;
  }

}

export default new audioProcessing();
